## THE NEW LOOK OF SILVA MD BOT FROM THE SILVA V SERIES

<p align="center">
  <a href="https://github.com/DenverCoder1/readme-typing-svg">
    <img src="https://readme-typing-svg.herokuapp.com?font=Time+New+Roman&color=purple&size=25&center=true&vCenter=true&width=600&height=100&lines=HEROKU+ERROR+FIXED+SILVA..&hearts;++;HEROKU+ERROR+FIXED,;HEROKU+ANTIBAN+ACTIVE,;NOW+DEPLOY+WITH+HEROKU,;UPDATE+YOUR+FORK,;AFTER+EVERY+2+DAYS..🥂💕">
  </a>
</p>
<h1 align="center"> 𝑺𝒊𝒍𝒗𝒂 𝒕𝒆𝒄𝒉
<img src="https://github.com/0xAbdulKhalid/0xAbdulKhalid/raw/main/assets/mdImages/handshake.gif" width ="80"></h1> 
 <br>

### we love silva md
<p align="center">
  <a href="https://github.com/DenverCoder1/readme-typing-svg">
    <img src="https://readme-typing-svg.herokuapp.com?font=Time+New+Roman&color=cyan&size=25&center=true&vCenter=true&width=600&height=100&lines=Hello+am+Silva+Tech..&hearts;++;Self-taught+Back-End+Developer,;From+Kenya🇰🇪,;My+Hobby+Is+Coding,;Active+Learner/Researcher,;Love+to+learn+new+stuffs..🥂💕">
  </a>
</p>

<p align="center"> Introducing 𝑺𝒊𝒍𝒗𝒂 𝒕𝒆𝒄𝒉, It is designed to bring a whole new level of excitement to your boring WhatsApp use. </p>

<p align="center">
  <a href="https://github.com/SilvaTechB/silva-md-bot">
    <img alt="Silva docs" height="300" src="https://telegra.ph/file/751eef74109e0e5c8916c.jpg">
  </a>
</p>
    
   
   
<p align="center">
  <a href="https://wa.me/+254700143167?text=Hi+Bro--+I+Need+Help.+I've+messaged+you+from+𝑺𝒊𝒍𝒗𝒂+𝒕𝒆𝒄𝒉 ʙᴏᴛ+Repo" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/ Whatsapp -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

</p>
<p align="center"><img src="https://profile-counter.glitch.me/{SilvaTechB}/count.svg" alt="𝑺𝒊𝒍𝒗𝒂 𝒕𝒆𝒄𝒉 ᴍᴅ :: Visitor's Count" /></p>

---




<p align="center"> 𝑺𝒊𝒍𝒗𝒂 𝒕𝒆𝒄𝒉 uses
  <a href="https://github.com/adiwajshing/Baileys">Multi-Device Baileys.</a>
</p>
<p align="center">
  <img title="Whatsapp-Bot-Javascript" src="https://img.shields.io/badge/Javascript-363303?style=for-the-badge&logo=linux&logoColor=c6c631"></img>
</p>

---


<p align="center">Need help? please create an <a href="https://github.com/SilvaTechB/silva-md-bot/issues">issue</a></p>


 <h3>silva tech Stats</h3>

![ Stats](https://github-readme-stats.vercel.app/api/pin/?username=SilvaTechB&repo=silva-md-bot&show_owner=true&theme=dark)


   
## Setup
---
1.  ***Fork Repo [`CLICK HERE`](https://github.com/SilvaTechB/silva-md-bot/fork) (A MUST) and `Star ⭐ Repository` for Courage.***
### SETUP

1. PAIRING
    <br>
<details>
<summary>CLICK HERE TO GET YOUR CREDS.JSON FILE</summary>
<a href='https://cred-session.onrender.com/pair' target="_blank"><img alt='PAIR CODE' src='https://img.shields.io/badge/Pair_code-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=blue'/></a>

</details>



<details>
<summary>CLICK HERE TO UPLOAD YOUR CREDS.JSON FILE</summary>
<a href='https://github.com/SilvaTechB/silva-md-bot/tree/main/Authenticators' target="_blank"><img alt='UPLOAD CREDS.JSON' src='https://img.shields.io/badge/UPLOAD_CREDS.JSON-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=red'/></a>

Then **[Upload](https://github.com/SilvaTechB/silva-md-bot/tree/main/Authenticators)** your creds.json file in the **[session folder](https://github.com/SilvaTechB/silva-md-bot/tree/main/Authenticators)**

### DELETE THE EXISTING CREDS.JSON FILE
</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

#### DEPLOY TO HEROKU 

1. If You don't have a account in Heroku. Create a account.
    <br>
<a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-blue?style=for-the-badge&logo=heroku&logoColor=white'/></a>

3. Now Deploy
    <br>
<a href='https://dashboard.heroku.com/new?template=https://github.com/SilvaTechB/s-ilva' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-purple?style=for-the-badge&logo=heroku&logoColor=white'/></a>
##
#### DEPLOY TO KOYEB 

1. If You don't have a account in koyeb. Create a account.
    <br>
<a href='https://app.koyeb.com/auth/signup' target="_blank"><img alt='koyeb' src='https://img.shields.io/badge/-Create-red?style=for-the-badge&logo=koyeb&logoColor=white'/></a>

3. Get [DATABASE_URL](https://github.com/SilvaTechB/silva-md-bot/wiki/DATABASE_URL) and copy it

4. Get [Koyeb api key](https://app.koyeb.com/account/api)

2. Now Deploy
    <br>
<a href='https://github.com/SilvaTechB/s-ilva' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-red?style=for-the-badge&logo=koyeb&logoColor=white'/></a>

#### DEPLOY TO RAILWAY

1. If You don't have a account in railway. Create a account.
    <br>
<a href='https://railway.app/login' target="_blank"><img alt='railway' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=railway&logoColor=white'/></a>

2. Now Deploy
    <br>
<a href='https://railway.app/template/q20OfH?referralCode=b9IKyc' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-purple?style=for-the-badge&logo=railway&logoColor=white'/></a>

For help visit [Github wiki](https://github.com/SilvaTechB/silva-md-bot/wiki)

***
<a href="https://whatsapp.com/channel/0029VaAkETLLY6d8qhLmZt2v"><img alt="WhatsApp" src="https://img.shields.io/badge/-Whatsapp%20Channel-maroom?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>


---


- Star ⭐ repo if you like this bot.
- If any problem, then [`Whatsapp Me Here`](https://wa.me/message/254700143167)


### I Am
- [Silva Tech](https://github.com/SilvaTechB)
-

<p align="center"> 
<img alt="Development" width="250" src="https://media2.giphy.com/media/W9tBvzTXkQopi/giphy.gif?cid=6c09b952xu6syi1fyqfyc04wcfk0qvqe8fd7sop136zxfjyn&ep=v1_internal_gif_by_id&rid=giphy.gif&ct=g" /> </p>



---
### Credits to:
- [Tech king](https://github.com/Sylivanu) for support

---


<h2 align="center">  NOTICE
</h2>
   
## 
- *silva tech is not made by `WhatsApp Inc.` Sometimes or misusing the bot might `ban` your `WhatsApp account!`*
- *In that case, I'm not responsible for banning your account.*
- *Use silva tech at your own risk by keeping this warning in mind.*
- [`Deploy on Heroku`](htttps://dashboard.heroku.com/new?template=https://github.com/SilvaTechB/s-ilva)
