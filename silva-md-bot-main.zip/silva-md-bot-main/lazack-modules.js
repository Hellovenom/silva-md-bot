//Shizo_modules importing system 
import GIFBufferToVideoBuffer from './Lazack/giftobuffer.js'
import displayLoadingScreen from './Lazack/loading.js'


//Shizo_modules quick access system
global.GIFBufferToVideoBuffer = GIFBufferToVideoBuffer
global.displayLoadingScreen = displayLoadingScreen
