let handler = async m =>
  m.reply(
    `

≡ 𝐒𝐈𝐋𝐕𝐀 𝐌𝐃 𝐁𝐎𝐓 GROUPS

─────────────
▢ Join public bot group and support
https://chat.whatsapp.com/Jjj2lYrtGHc5WY2rUmC6JD

▢ Group 
https://chat.whatsapp.com/Lr80ac3MKKIKGew8mFES2a

─────────────
≡ Disabled links? enter here! 

▢ Channel WhatsApp 
 https://whatsapp.com/channel/0029VaAkETLLY6d8qhLmZt2v
─────────────
▢ *Owner instagram*
 https://instagram.com/_its.silva

▢ *YouTube*
• https://www.youtube.com/@silvaedits254


`.trim()
  )
handler.help = ['ruth']
handler.tags = ['main']
handler.command = ['groups', 'groupsilva', 'silvagp', 'sgp', 'grp']

export default handler
